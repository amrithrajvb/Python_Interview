a="hello,world"
b=a.split(",")
print(b)
for i in b:
    print(i)
#result show like list